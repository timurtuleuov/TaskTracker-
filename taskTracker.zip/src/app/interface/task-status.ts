export enum TaskStatus {
    Todo = 'todo',
    Doing = 'doing',
    Done = 'done'
  }