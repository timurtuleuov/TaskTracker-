export interface Tag {
    id: string;
    title: string;   
}