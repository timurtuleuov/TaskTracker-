export interface TaskTheme{
    id: string,
    title: string;
}